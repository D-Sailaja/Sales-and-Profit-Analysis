import pandas as pd

df = pd.read_csv("data/sales_data.csv")
print(df.head())

print("\nTotal Sales:", df["Sales"].sum())
print("Total Profit:", df["Profit"].sum())

grouped = df.groupby("Category")[["Sales","Profit"]].sum()
print("\nCategory-wise Summary:\n", grouped)
