# Sales and Profit Analysis

This project analyzes retail sales data to understand revenue and profit trends.

## Structure
- data/: dataset
- scripts/: python analysis script
- notebooks/: EDA notebook
- powerbi/: (add your .pbix)
- images/: (screenshots)
